version 2.0  program to make ps2 cds.

Usage Manual
============

First off it must be noted that the program is divided in two areas of work: the View of the directory tree.  we can observe the structure of directories (as well as select them)the menu to the right is the area of work itself. the bar of icons located in the left side, will soon be explained. 


Specifications
-------------------------

the program, at the moment, only supports work with a maximum of 1024 folders (or directories) and with maximum of 4096 files. the program outputs cd images to BIN or ISO of 2352 bytes per sector and calculates the ECC/EDC. The size of images can vary from as little as 2 seconds to massive images capable of being burned to DVD-R. The time can be controlled by the user so that it does not go off past the limit them of the CD the time. global size and other information is in the status bar. 



File and Directory Rules
-----------------------------------------------------

The format of the PS2, this prepared to work with files with maximum of 8 characters and 3 letters to the file extension in ALL capital letters. All of the letters of the alphabet are allowed.Spaces are not allowed as well. In the case of the directories, these do not require extensions. 

No less important, it is the rules of the LBA: When we fixed a LBA, directories and files within a directory, have priority before files in the root of the cd project. and the first introduced file has priority on the later ones. We cannot either fix the LBA anywhere when the directories, this it cannot be inferior to the one of I complete LBA pertaining to the raiz directory. In the case of the files, the confused rule can be something but, but in general, they are placed in the first hollow in which the file starting off of the LBA fits but under free (), except we fixed it to another place. 

If two files 'collide' in the LBA,Then the file with the greater priority will have the LBA value and the other is automatically set to a lower priority than the recently changed LBA. This also means that many other files may be affected by the move. you can notice possible changes with a warning. Now, before creating the image it warns to you that one or several LBA settings have been displaced. At this time an internal check is made to the current project integrity to avoid cd burning failure (face burning a cup coaster). in other words when it sees something that it doesnt like, it warns to you. 


How To Work The Program
-----------------------------------------


we have already some of the basics of the cd structure and opening or of saving the structure from the CD and having the capabilities of being able to construct the image and to save it to the disc in two formats:BIN+CUE and ISO. Using the icons on the left, we can change the label of the volume, the one of the disc CD labeled like ' VOL'.Also on the left bar you can change the date of your creation and the name of the disc. You can also select this from the top menu File->Edit Volume. 

And now that? Then to work, you will need to have open a window of the explorer. Here you can select the files or routes that you want on the cd and drag them into the right main work window. If everything has gone well, the files you will appear in the main work window. If the files do not appear in the main work window a menu will appear with a list of the possible errors. If an error occurs an explanation will appear: a yellow exclamacion means that the program has tried to introduce a directory that already exists. but as long as they fulfill the basic rules, clear.

The files can be moved in the main work window one by one to interchange their position with one another towards an inferior or superior directory (this is done by holding the left mouse button and dragging towards the position we want to move. While moving a file the cursor of the mouse will begin to change. The selection multiple of files.to erase or edit a file, select the file with the left mouse button then press the right mouse button. A small menu will appear with the words erase and edit.

while in the small menu using the right button on a file or directory, you will have the option TO erase or delete the file. you can also choose TO publish, change the name, date and also fix the LBA as long as it does not contradict the file sorting rules. 


Creating folders:
 The first thing you must do is to press the icon of the left that says "NEW" with symbol of a folder (also in menu Edit-->create directory). you can always create directories within windows explorer also. It is necessary to note that directories normally situate themselves Before the data of the files. 

 
Creating a'Dummy':
 An dummy, is a very special file, not exactly a functional file by the cd or the ps2 in this case. It is created pressing on the icon that says new with the symbol of a white sheet of paper or in menu Edit-->Create a dummy. In the edit window, we can put a name the date and also fix a LBA and the length, although this is not necessary normally. The dummy, is used normally used to match the LBA of another cd for example the gameshark/action replay2 and simillar discs that are used too boot backups and demos. Dummy files can also be used to push useable file forward onto the cd to prevent wear and tear on your laser. 


CD Image Creation 
-------------

once you have checked over your new cd project you will need to have an image to burn. All you need to do is press the icon of the CD marked ' IMG' or in menu File-->Record image. Once you have selected this a small window will appear where we will be able to select which file format to use BIN/CUE or ISO9660 compliant Image. This document will not cover the final Burning process. If you are not sure how to burn a cd then please choose the iso file format and use your favorite cd burning program to burn at MODE2XA.



PS2 Files
------------


.PS2 extensions is the file format with which we can keep the information about a cd project. It is controlled with the three icons that have simbolo of the program (New, To load and To save) 



Iprovements added from the previous beta version: (27-12-2001) 
- the creation system of of folders and alias have been fixed for several failures that occured in which the file structure failed 
- the CUE bug has been fixed 
- ISO9660 image format is now supported 
- Added a system that verifies the integrity of the current cd file system, before generating the image (used to avoid cd burning failures) 
- drag and dropa file is now supported on the left window that contains the structure of files 
- support has been added to save cd file structure of the compilations (format ps2) 
- improvements in the internal processes 


VERSION 1.5 13-3-2002 
- Corrected the failures when including files of extension 0 
- Corrected smaller failures, than they hacian that it was hung in the window of entrance in some cases 
- Now the character ' - ' is admitted (nonstandard character, which it is included in NAPLINK, for example) 
- Corrected a failure, where the Bin did not include a cue and the iso included a cue NOTE:  I hope it fully works without any problems.  I apologize for how badly this bug may have bothered users in 1.2, but apparently i did not upload the correct version and no one warned me about this earlier hehe..  

Version 2.0 7-11-2002
- Corrected misc. bugs
-Added support for filenames with up to 31 characters
-renamed cdgenps2 format from .psd to .ps2, you can simply rename your old files to ps2
Loose English Translation By Guichi
http://ps2newz.net
------------